package resources;



import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Base {
	
	public Properties prop;
	
	public WebDriver initializeBrowser() throws IOException {
	WebDriver driver = null;
	
	 prop = new Properties();
	String propertiesPath = System.getProperty("user.dir")+"\\src\\main\\java\\resources\\config.properties";
	FileInputStream fis = new FileInputStream(propertiesPath);
	prop.load(fis);
	
	String browserName = prop.getProperty("browser");
	
	if(browserName.equalsIgnoreCase("chrome"))
	    {
		 WebDriverManager.chromedriver().setup();
		  driver = new ChromeDriver();
		  } 
	 
	 driver.manage().window().maximize();
	
	 
	 return driver;
     }
 
 
}
