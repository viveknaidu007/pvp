package com.pvptestCase;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageobjects.Accountpage;
import pageobjects.HomePage;
import pageobjects.Loginpage;
import resources.Base;

public class LoginTest extends Base {
	
	WebDriver driver;
	
	@BeforeMethod
	public void openApplication() throws IOException {
		
		driver = initializeBrowser();
		driver.get(prop.getProperty("url"));
		
	}
	
	
	@Test(dataProvider="getLoginData")
	public void login(String email,String password,String expectedResult) throws IOException, InterruptedException {
		
		
		
		HomePage homepage = new HomePage(driver);
		homepage.myAccountDropdown().click();
		homepage.loginOption().click();
		
         Thread.sleep(3000);
		
		Loginpage loginPage = new Loginpage(driver);
		//loginPage.emailAddressTextField().sendKeys(prop.getProperty("email"));
		loginPage.emailAddressTextField().sendKeys(email);
		//loginPage.passwordField().sendKeys(prop.getProperty("password"));
		loginPage.passwordField().sendKeys(password);
		loginPage.loginButton().click();
		
        Accountpage accountPage = new Accountpage(driver);
        
         String acutualResult = null;
		
		try {
			
			if(accountPage.editYourAccountInformation().isDisplayed()) {
			   acutualResult = "Success";
			}
			
		}catch(Exception e) {
			
			acutualResult = "Failure";
			
		}
		
		Assert.assertEquals(acutualResult,expectedResult);
		
		//Assert.assertTrue(accountPage.editYourAccountInformation().isDisplayed());
	}
	@AfterMethod
	public void closure() {
		
		driver.close();
		
	}
	
	@DataProvider
	public Object[][] getLoginData() {
		
		Object[][] data = {{"arun.selenium@gmail.com","Second@123","Success"},{"dummy@test.com","1234","Failure"}};
		
		return data;
		
	}
	
	

}