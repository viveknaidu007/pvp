package com.pvptestCase;

import org.testng.annotations.Test;

public class Test2 {
	
	
	@Test
	public void test2() {
		System.out.println("Inside Test 2");
	}

}
