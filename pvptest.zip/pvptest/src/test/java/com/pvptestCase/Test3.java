package com.pvptestCase;

import org.testng.annotations.Test;

public class Test3 {
	

	@Test
	public void test3() {
		System.out.println("Inside Test 3");
	}

}
