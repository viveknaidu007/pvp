package com.pvptestCase;

import org.testng.annotations.Test;

public class Test4 {
	
	

	@Test
	public void test4() {
		System.out.println("Inside Test 4");
	}

}
