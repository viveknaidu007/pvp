package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Accountpage {

WebDriver driver;
	
    public Accountpage(WebDriver driver){
    	
    	this.driver = driver;
    	
    	PageFactory.initElements(driver,this);
    	    	
    }
    
    @FindBy(xpath = "//span[text()='Order history and details']")
	private WebElement orderHistory;
    
    
    @FindBy(id="search_query_top")
	private WebElement searchProductBox;
	
	@FindBy(name="submit_search")
	private WebElement searchButton;
    
    
    public WebElement orderHistory() {
    	
    	return orderHistory;
    	
    }
    
public WebElement searchProductBox() {
    	
    	return searchProductBox;
    	
    }



public WebElement searchButton() {
	
	return searchButton;
	
}
    
}