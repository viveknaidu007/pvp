package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Loginpage {

WebDriver driver;

public Loginpage(WebDriver driver) {
	
	this.driver = driver;
	PageFactory.initElements(driver,this);

}

@FindBy(id="email")
private WebElement userName;

@FindBy(id="passwd")
private WebElement password;

@FindBy(id="SubmitLogin")
private WebElement signInBtn;

public WebElement userName() {
	
	return userName;
	
}

public WebElement password() {
	
	return password;
	
}

public WebElement signInBtn() {
	
	return signInBtn;
	
}




}
