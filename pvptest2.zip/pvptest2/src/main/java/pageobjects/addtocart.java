package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;





public class addtocart {
WebDriver driver;

	
	public addtocart(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver,this);
		
	}
	
	
	
	@FindBy(id="quantity_wanted")
	private WebElement quantity;
	
	@FindBy(name="group_1")
	private WebElement size;
	
	
	
	@FindBy(xpath="//span[text()='Add to cart']")
	private WebElement addToCartBtn;
	
	@FindBy(xpath="//*[@id=\"layer_cart\"]//h2/i")
	private WebElement addToCartMessag;
	
	@FindBy(xpath="//span[contains(text(),'Proceed to checkout')]")
	private WebElement proceedToCheckOutBtn;
	
	
	
	public WebElement quantity() {
		
		return quantity;
		
	}

	public WebElement size() {
		
		return size;
		
	}

	public WebElement addToCartBtn() {
		
		return addToCartBtn;
		
	}

	public WebElement addToCartMessag() {
		
		return addToCartMessag;
	}
	
public WebElement proceedToCheckOutBtn() {
		
		return proceedToCheckOutBtn;
	}
	

}
