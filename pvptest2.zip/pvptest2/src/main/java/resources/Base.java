package resources;



import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Base {
	
	public Properties prop;
	
	public WebDriver initializeBrowser() throws IOException {
	WebDriver driver = null;
	
	 prop = new Properties();
	String propertiesPath = System.getProperty("user.dir")+"\\src\\main\\java\\resources\\config.properties";
	FileInputStream fis = new FileInputStream(propertiesPath);
	prop.load(fis);
	
	String browserName = prop.getProperty("browser");
	
	if(browserName.equalsIgnoreCase("chrome"))
	    {
		 WebDriverManager.chromedriver().setup();
		  driver = new ChromeDriver();
		  } 
	 
	 driver.manage().window().maximize();
	
	 
	 return driver;
     }
	
       public String takeScreenshot(String testName,WebDriver driver) throws IOException {
		
		File SourceFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		String destinationFilePath = System.getProperty("user.dir")+"\\screenshots\\"+testName+".png";
		FileUtils.copyFile(SourceFile,new File(destinationFilePath));
		return destinationFilePath;
	
}
       
       
       public boolean type(WebElement ele, String text) {
   		boolean flag = false;
   		try {
   			flag = ele.isDisplayed();
   			ele.clear();
   			ele.sendKeys(text);
   			// logger.info("Entered text :"+text);
   			flag = true;
   		} catch (Exception e) {
   			System.out.println("Location Not found");
   			flag = false;
   		} finally {
   			if (flag) {
   				System.out.println("Successfully entered value");
   			} else {
   				System.out.println("Unable to enter value");
   			}

   		}
   		return flag;
   	}
       
       
       public boolean selectByVisibleText(String visibletext, WebElement ele) {
   		boolean flag = false;
   		try {
   			Select s = new Select(ele);
   			s.selectByVisibleText(visibletext);
   			flag = true;
   			return true;
   		} catch (Exception e) {
   			return false;
   		} finally {
   			if (flag) {
   				System.out.println("Option selected by VisibleText");
   			} else {
   				System.out.println("Option not selected by VisibleText");
   			}
   		}
   	}
	
	}

		
 
 

