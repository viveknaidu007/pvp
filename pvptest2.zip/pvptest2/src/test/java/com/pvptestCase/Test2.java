package com.pvptestCase;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import resources.Base;

public class Test2 extends Base {
	
	
	@Test
	public void test2() throws IOException, InterruptedException {
		System.out.println("Inside Test 2");
		WebDriver driver = initializeBrowser();
		driver.get("https://www.youtube.com/");
		
		Thread.sleep(2000);
		
		driver.close();
		
	}

}
