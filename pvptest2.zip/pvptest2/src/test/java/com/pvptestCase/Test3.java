package com.pvptestCase;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import resources.Base;


	
	public class Test3 extends Base {
		
		
		@Test
		public void test3() throws IOException, InterruptedException {
			System.out.println("Inside Test 3");
			WebDriver driver = initializeBrowser();
			driver.get("https://www.youtube.com/");
			
			Thread.sleep(2000);
			
			driver.close();
			
		}

}
