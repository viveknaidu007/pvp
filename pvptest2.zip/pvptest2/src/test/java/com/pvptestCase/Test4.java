package com.pvptestCase;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import resources.Base;

public class Test4 extends Base {
	
	
	public WebDriver driver;
	
	
	@Test
	public void test4() throws IOException, InterruptedException {
		System.out.println("Inside Test 4");
		 driver = initializeBrowser();
		driver.get("https://www.youtube.com/");
		
		Thread.sleep(2000);
		
		Assert.assertTrue(false);
		
		
		
	}
	
	@AfterMethod
	public void closing()
	
	{
		driver.close();
	}

}
